# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 9e381e74577a5ea8922e49f630b61f11
- Android key alias: c0a7121832821533cf402df83938cb83
- Android key password: 5137f879aa7708479749bc5580415e09
      